import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { Presentation, PresentationFile } from '@oai/artifact-tool';

const ROOT='C:/Users/user/Documents/android-1';
const BUILD=path.join(ROOT,'.ppt-build');
const OUT=path.join(ROOT,'ppt-output');
const ASSETS=path.join(ROOT,'.ppt-assets');
const SKILL='C:/Users/user/.codex/plugins/cache/openai-primary-runtime/presentations/26.1025.11240/skills/presentations';
const PY='C:/Users/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
const FINAL=path.join(OUT,'portfolio_site_guide_all_v2.pptx');
const FONT='Malgun Gothic';
const C={bg:'#090708',panel:'#151112',red:'#A53242',light:'#E06B77',white:'#F7F2F3',muted:'#A99FA2',line:'#3A292D',gold:'#DAB677',green:'#67B47C'};

async function bytes(file){const b=await fs.readFile(file);return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)}
function box(slide,x,y,w,h,fill=C.panel,line='none',radius='rounded-xl'){
  return slide.shapes.add({geometry:'roundRect',position:{left:x,top:y,width:w,height:h},fill,line:line==='none'?{fill:'none',width:0}:{fill:line,width:1,style:'solid'},borderRadius:radius});
}
function text(slide,value,x,y,w,h,size=24,color=C.white,bold=false,align='left'){
  const s=slide.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
  s.text=value;s.text.style={typeface:FONT,fontSize:size,color,bold,alignment:align,verticalAlignment:'middle',autoFit:'shrinkText'};return s;
}
function base(slide,section,num){slide.background.fill=C.bg;text(slide,section.toUpperCase(),72,34,420,24,13,C.light,true);text(slide,String(num).padStart(2,'0'),1160,34,48,24,13,C.muted,true,'right');slide.shapes.add({geometry:'line',position:{left:72,top:67,width:1136,height:1},line:{fill:C.line,width:1,style:'solid'}})}
function title(slide,t,sub){text(slide,t,72,90,1136,70,46,C.white,true);if(sub)text(slide,sub,72,160,1080,48,22,C.muted,false)}
function shotTitle(slide,t,sub){text(slide,t,72,90,570,70,46,C.white,true);if(sub)text(slide,sub,72,160,560,70,22,C.muted,false)}
async function shot(slide,name,x=700,y=150,w=508,h=430){slide.images.add({blob:await bytes(path.join(ASSETS,`${name}.png`)),contentType:'image/png',alt:`${name} 페이지 화면`,fit:'cover',position:{left:x,top:y,width:w,height:h},geometry:'roundRect',borderRadius:'rounded-xl'})}
function point(slide,n,heading,body,y,x=72,w=540){text(slide,String(n).padStart(2,'0'),x,y,42,28,15,C.light,true);text(slide,heading,x+58,y-2,w-58,34,25,C.white,true);text(slide,body,x+58,y+38,w-58,68,20,C.muted,false)}
function code(slide,value,x,y,w,h){box(slide,x,y,w,h,'#0D0B0C',C.line);text(slide,value,x+24,y+18,w-48,h-36,18,'#EADFE1',false)}
function sectionSlide(slide,label,t,desc,num){base(slide,label,num);text(slide,t,110,210,1060,100,58,C.white,true,'center');text(slide,desc,210,330,860,80,24,C.muted,false,'center');slide.shapes.add({geometry:'line',position:{left:500,top:455,width:280,height:4},line:{fill:C.red,width:4,style:'solid'}})}

const p=Presentation.create({slideSize:{width:1280,height:720}});
let n=0;

// 1 Cover
{
  const s=p.slides.add();n++;s.background.fill=C.bg;
  s.images.add({blob:await bytes(path.join(ROOT,'images/portfolio-icon.png')),contentType:'image/png',alt:'포트폴리오 아이콘',fit:'contain',position:{left:72,top:64,width:74,height:74}});
  text(s,'MY PORTFOLIO',170,74,420,40,20,C.light,true);
  text(s,'포트폴리오 웹사이트\n구성과 기능 설명',72,205,850,154,62,C.white,true);
  text(s,'자기소개부터 코드 강좌까지, 사이트의 각 요소를 이해하기 쉽게 정리한 발표 자료',76,402,920,68,25,C.muted,false);
  text(s,'김재환 · 2026',76,610,320,30,18,C.muted,false);
  s.shapes.add({geometry:'line',position:{left:1030,top:86,width:178,height:5},line:{fill:C.red,width:5,style:'solid'}});
}

// 2 Overview
{
  const s=p.slides.add();n++;base(s,'Overview',n);title(s,'사이트 전체 구조','방문자는 소개 정보를 살펴보고, 기능을 사용하며, 강좌에서 직접 학습합니다.');
  point(s,1,'포트폴리오','자기소개, 인적사항, 학습 기록과 프로젝트 경험을 보여줍니다.',220,82,350);
  point(s,2,'사용자 기능','아이디어 저장, 로그인·회원가입, 배경음악을 브라우저에서 사용할 수 있습니다.',220,465,350);
  point(s,3,'코드 학습','HTML, C, C++ 강좌에서 설명·코드·퀴즈를 단계별로 학습합니다.',220,848,350);
  text(s,'페이지 이동 흐름',82,420,250,32,22,C.light,true);
  text(s,'자기소개  ›  인적사항  ›  학습사항  ›  경력사항  ›  아이디어  ›  코드강좌',82,474,1110,54,28,C.white,true);
  text(s,'모든 페이지는 같은 내비게이션과 검은색·붉은색 디자인을 공유합니다.',82,552,1100,42,21,C.muted,false);
}

// 3 Design
{
  const s=p.slides.add();n++;base(s,'Design',n);title(s,'검은색과 붉은색 중심의 디자인','어두운 배경이 콘텐츠를 집중해서 보게 하고, 붉은색이 버튼과 현재 위치를 강조합니다.');
  text(s,'배경',84,238,140,30,18,C.muted,true);box(s,84,280,250,100,C.bg,C.line);text(s,'#090708',105,310,210,32,23,C.white,true,'center');
  text(s,'강조색',390,238,140,30,18,C.muted,true);box(s,390,280,250,100,C.red,'none');text(s,'#A53242',411,310,208,32,23,C.white,true,'center');
  text(s,'본문',696,238,140,30,18,C.muted,true);box(s,696,280,250,100,C.white,'none');text(s,'#F7F2F3',717,310,208,32,23,C.bg,true,'center');
  text(s,'보조 글자',1002,238,150,30,18,C.muted,true);box(s,1002,280,190,100,C.muted,'none');text(s,'#A99FA2',1018,310,158,32,21,C.bg,true,'center');
  point(s,1,'큰 제목','페이지의 목적을 한눈에 이해하도록 제목 크기를 크게 설정했습니다.',468,84,350);
  point(s,2,'넓은 여백','요소 사이를 충분히 띄워 내용이 복잡해 보이지 않도록 했습니다.',468,465,350);
  point(s,3,'일관된 강조','활성 메뉴, 버튼, 진행률에 같은 붉은색을 사용합니다.',468,846,350);
}

// 4 Navigation
{
  const s=p.slides.add();n++;base(s,'Navigation',n);title(s,'내비게이션과 반응형 화면','로고에 마우스를 올리면 메뉴가 나타나고, 작은 화면에서는 공간에 맞춰 배치가 바뀝니다.');
  box(s,78,236,1124,82,'#0D0A0B',C.line);text(s,'◉  MY PORTFOLIO',104,253,270,45,23,C.white,true);text(s,'자기소개    인적사항    학습사항    경력사항    아이디어    코드강좌    로그인',430,253,720,45,19,C.muted,true,'center');
  point(s,1,'마우스 드롭다운','로고 주변에 마우스를 올리거나 키보드로 접근하면 전체 메뉴를 확인할 수 있습니다.',380,84,520);
  point(s,2,'현재 페이지 표시','방문자가 어느 페이지에 있는지 활성 메뉴의 색으로 알려줍니다.',500,84,520);
  point(s,3,'모바일 대응','화면이 좁아지면 글자와 열 배치가 줄어들어 휴대전화에서도 읽을 수 있습니다.',380,674,520);
  point(s,4,'동적 메뉴 추가','공통 스크립트가 코드강좌와 로그인 메뉴를 모든 페이지에 자동으로 추가합니다.',500,674,520);
}

// 5 Introduction
{
  const s=p.slides.add();n++;base(s,'Portfolio',n);shotTitle(s,'자기소개 페이지','첫 화면에서 이름, 개발 목표, 관심 분야를 간결하게 전달합니다.');await shot(s,'intro');
  point(s,1,'소개 문장','예비 개발자로서 배우고 만드는 과정을 중요하게 생각한다는 방향을 보여줍니다.',228,72,560);
  point(s,2,'프로필 사진 선택','사용자가 자신의 사진을 선택하고 즉시 미리볼 수 있습니다.',364,72,560);
  point(s,3,'키워드 태그','웹개발, UI·UX, 꾸준한 성장이라는 관심사를 짧게 요약합니다.',500,72,560);
}

// 6 Profile
{
  const s=p.slides.add();n++;base(s,'Portfolio',n);shotTitle(s,'인적사항 페이지','기본 정보와 연락 방법을 표로 정리해 빠르게 확인할 수 있습니다.');await shot(s,'info');
  point(s,1,'기본 정보 표','이름, 거주지, 관심 분야, GitHub와 현재 상태를 행별로 구분합니다.',228,72,560);
  point(s,2,'연락처 연결','이메일과 전화번호를 누르면 바로 해당 앱이나 서비스로 이동합니다.',364,72,560);
  point(s,3,'접근하기 쉬운 구조','표의 제목 셀과 링크 문구가 정보의 의미를 분명하게 전달합니다.',500,72,560);
}

// 7 Smart links
{
  const s=p.slides.add();n++;base(s,'Smart links',n);title(s,'외부 서비스 연결','연락과 위치 확인에 필요한 기능을 한곳에서 바로 실행합니다.');
  point(s,1,'Gmail','새 메일 작성 화면을 열고 받는 사람 주소를 자동으로 입력합니다.',220,82,520);
  point(s,2,'전화','휴대전화에서 010-5731-5766으로 바로 통화를 시작합니다.',348,82,520);
  point(s,3,'Instagram','SNS 프로필을 새 탭에서 열어 개인 활동을 확인할 수 있습니다.',476,82,520);
  point(s,4,'Google 지도','장안대학교 위치와 서울특별시 주소를 지도에서 확인합니다.',604,82,520);
  code(s,'Gmail 링크      https://mail.google.com/...\n전화번호 링크   tel:+821057315766\nSNS 링크        instagram.com/kim_jh627\n위성좌표 링크   Google Maps',700,228,500,330);
}

// 8 Study
{
  const s=p.slides.add();n++;base(s,'Portfolio',n);shotTitle(s,'학습사항 페이지','배운 내용을 시간 순서로 정리해 성장 과정을 보여줍니다.');await shot(s,'study');
  point(s,1,'2026년 5월부터 6월','HTML5와 CSS3의 문서 구조, 레이아웃과 접근성을 학습했습니다.',220,72,560);
  point(s,2,'2026년 7월부터 8월','JavaScript의 DOM, 이벤트, 배열과 객체를 실습했습니다.',360,72,560);
  point(s,3,'현재와 다음 목표','반응형 포트폴리오를 제작하고 React 학습을 다음 단계로 설정했습니다.',500,72,560);
}

// 9 Career
{
  const s=p.slides.add();n++;base(s,'Portfolio',n);shotTitle(s,'경력사항 페이지','프로젝트 경험을 기간, 설명, 사용 기술로 나누어 보여줍니다.');await shot(s,'career');
  point(s,1,'개인 포트폴리오','기획부터 반응형 HTML·CSS 구현까지 직접 진행한 경험입니다.',220,72,560);
  point(s,2,'팀 웹 프로젝트','정보 구조와 주요 화면을 설계하고 팀원과 협업한 경험입니다.',360,72,560);
  point(s,3,'웹 개발 기초 과정','웹 표준, 접근성, 시맨틱 마크업을 학습한 과정을 정리했습니다.',500,72,560);
}

// 10 Ideas
{
  const s=p.slides.add();n++;base(s,'Interactive feature',n);shotTitle(s,'아이디어 기록과 저장','떠오른 생각을 작성하고 수정·삭제할 수 있으며 브라우저를 닫아도 기록이 남습니다.');await shot(s,'ideas');
  point(s,1,'입력','제목은 60자, 내용은 1,000자까지 작성할 수 있습니다.',220,72,560);
  point(s,2,'저장','localStorage에 JSON 형태로 보관해 같은 브라우저에서 다시 불러옵니다.',360,72,560);
  point(s,3,'관리','저장된 카드에서 수정과 삭제를 선택하고 개수도 확인할 수 있습니다.',500,72,560);
}

// 11 Auth
{
  const s=p.slides.add();n++;base(s,'Member feature',n);shotTitle(s,'로그인과 회원가입','학습용 회원 기능으로 가입, 로그인, 세션 유지와 로그아웃을 체험합니다.');await shot(s,'auth');
  point(s,1,'회원가입','이름, 이메일, 비밀번호를 검사하고 브라우저 저장소에 회원 정보를 저장합니다.',220,72,560);
  point(s,2,'비밀번호 처리','가능한 환경에서는 SHA-256으로 비밀번호 값을 변환합니다.',360,72,560);
  point(s,3,'중요한 제한','실제 서버 인증이 아니므로 개인 학습과 기능 시연 목적으로만 사용합니다.',500,72,560);
}

// 12 Music
{
  const s=p.slides.add();n++;base(s,'Media feature',n);title(s,'배경음악 플레이어','모든 주요 페이지에서 음악을 재생하고 이전 재생 위치와 음량을 기억합니다.');
  code(s,"const audio = new Audio('../audio/aruarian-dance.mp3');\naudio.loop = true;\naudio.volume = saved.volume;",82,230,530,220);
  point(s,1,'재생과 일시정지','화면 아래 플레이어 버튼으로 음악 상태를 바꿉니다.',230,690,500);
  point(s,2,'음량 저장','사용자가 선택한 음량을 localStorage에 저장합니다.',350,690,500);
  point(s,3,'재생 위치 복원','페이지를 이동해도 마지막 재생 시간을 다시 적용합니다.',470,690,500);
}

// 13 Local storage
{
  const s=p.slides.add();n++;base(s,'Data',n);title(s,'브라우저 저장소의 역할','서버가 없어도 학습 기록과 사용자 설정을 같은 브라우저에서 유지합니다.');
  point(s,1,'아이디어','my-portfolio-ideas-v1에 제목, 내용, 수정 시간을 저장합니다.',205,86,500);
  point(s,2,'회원과 세션','portfolio-users-v1과 portfolio-session-v1에 학습용 계정 상태를 저장합니다.',325,86,500);
  point(s,3,'음악','portfolio-background-music에 재생 상태, 위치, 음량을 저장합니다.',445,86,500);
  point(s,4,'강좌 진도','언어별 키에 완료 단원과 수정한 코드를 저장합니다.',565,86,500);
  box(s,690,215,470,340,'#0D0B0C',C.line);text(s,'localStorage',720,245,410,52,34,C.light,true,'center');text(s,'브라우저 내부에만 저장\n다른 기기와 자동 공유되지 않음\n브라우저 데이터를 지우면 함께 삭제',738,330,374,150,23,C.white,false,'center');
}

// 14 Course overview
{
  const s=p.slides.add();n++;base(s,'Code archive',n);shotTitle(s,'코드 강좌 허브','검색, 언어 필터, 학습 경로 추천과 짧은 코드 예제를 한 페이지에 모았습니다.');await shot(s,'courses');
  point(s,1,'강좌 찾기','검색어와 웹·JavaScript·C/C++ 필터로 원하는 내용을 좁힙니다.',220,72,560);
  point(s,2,'학습 경로','현재 수준과 목표를 선택하면 적합한 시작 강좌를 추천합니다.',360,72,560);
  point(s,3,'코드 실험','HTML, CSS, JavaScript 예제와 결과를 탭으로 비교합니다.',500,72,560);
}

// 15 Path and curriculum
{
  const s=p.slides.add();n++;base(s,'Code archive',n);title(s,'강좌를 선택하는 방법','초보자는 웹 구조부터 시작하고, 원리를 깊게 배우려면 C 계열 강좌로 이동합니다.');
  point(s,1,'처음 시작해요','HTML 입문과 자기소개 페이지 실습으로 웹 문서 구조를 익힙니다.',218,86,520);
  point(s,2,'웹을 만들고 싶어요','HTML을 복습한 뒤 CSS와 JavaScript 학습으로 이어집니다.',350,86,520);
  point(s,3,'원리를 깊게 알고 싶어요','C 언어의 메모리와 포인터를 배우고 C++ 객체지향으로 확장합니다.',482,86,520);
  box(s,690,222,470,330,'#100D0E',C.line);text(s,'학습 순서',720,248,410,44,24,C.light,true,'center');text(s,'HTML 구조\n\nCSS 디자인\n\nJavaScript 동작\n\nC와 C++ 원리',744,314,362,208,26,C.white,true,'center');
}

// 16 HTML course screenshot
{
  const s=p.slides.add();n++;base(s,'HTML Course',n);shotTitle(s,'HTML 입문 강좌','8개 단원에서 웹 문서의 구조를 배우고 자기소개 페이지를 완성합니다.');await shot(s,'html-course');
  point(s,1,'설명과 예제','제목, 문단, 링크, 이미지, 목록, 표, 폼과 시맨틱 태그를 배웁니다.',220,72,560);
  point(s,2,'즉시 미리보기','왼쪽 HTML 코드를 수정하면 오른쪽 브라우저 결과가 바로 바뀝니다.',360,72,560);
  point(s,3,'퀴즈와 진도','학습 완료 상태를 저장하고 마지막 퀴즈로 핵심 개념을 점검합니다.',500,72,560);
}

// 17 HTML lesson map
{
  const s=p.slides.add();n++;base(s,'HTML Course',n);title(s,'HTML 강좌 단원별 핵심','문서의 기본 구조에서 시작해 완성된 자기소개 페이지까지 단계적으로 이어집니다.');
  point(s,1,'웹과 HTML','태그가 내용의 의미와 구조를 브라우저에 전달합니다.',205,80,520);
  point(s,2,'제목·문단·링크·이미지','정보를 읽기 쉽게 나누고 다른 문서와 연결합니다.',325,80,520);
  point(s,3,'목록·표·입력 폼','여러 항목과 데이터를 정리하고 사용자 입력을 받습니다.',445,80,520);
  point(s,4,'시맨틱 구조와 실습','header, main, section을 사용해 자기소개 페이지를 만듭니다.',565,80,520);
  code(s,'<main>\n  <section>\n    <h2>나의 소개</h2>\n    <p>배운 내용을 하나의 페이지로 구성합니다.</p>\n  </section>\n</main>',690,218,480,360);
}

// 18 C course screenshot
{
  const s=p.slides.add();n++;base(s,'C Course',n);shotTitle(s,'C 언어 입문 강좌','8개 단원에서 문법과 메모리의 기본 원리를 배웁니다.');await shot(s,'c-course');
  point(s,1,'기본 문법','변수, 자료형, 입출력, 조건문과 반복문을 학습합니다.',220,72,560);
  point(s,2,'데이터와 메모리','배열, 문자열, 함수와 포인터가 메모리에서 동작하는 방식을 설명합니다.',360,72,560);
  point(s,3,'예상 출력','브라우저에서 코드를 읽고 수정하며 예제의 예상 결과를 비교합니다.',500,72,560);
}

// 19 C lesson map
{
  const s=p.slides.add();n++;base(s,'C Course',n);title(s,'C 강좌 단원별 핵심','기초 문법을 충분히 익힌 뒤 포인터로 메모리 주소를 다룹니다.');
  point(s,1,'프로그램 구조','main 함수와 printf를 사용해 첫 프로그램을 작성합니다.',205,80,520);
  point(s,2,'제어 흐름','if와 반복문으로 조건과 반복 작업을 표현합니다.',325,80,520);
  point(s,3,'배열과 함수','여러 값을 묶고 코드를 기능 단위로 분리합니다.',445,80,520);
  point(s,4,'포인터','변수의 주소를 저장하고 원본 값을 함수에서 수정합니다.',565,80,520);
  code(s,'int value = 10;\nint *pointer = &value;\n*pointer = 20;\n\nprintf("%d\\n", value);  // 20',690,250,480,250);
}

// 20 C++ screenshot
{
  const s=p.slides.add();n++;base(s,'C++ Course',n);shotTitle(s,'C++ 입문 강좌','C의 기본 원리에서 클래스, 객체와 다형성으로 학습 범위를 넓힙니다.');await shot(s,'cpp-course');
  point(s,1,'현대적인 문법','string, vector, 참조를 사용해 데이터를 편리하게 다룹니다.',220,72,560);
  point(s,2,'객체지향','클래스, 생성자, 상속과 가상 함수를 단계적으로 배웁니다.',360,72,560);
  point(s,3,'수정 결과 미리보기','cout 문자열과 기본 변수, 객체 메서드 호출을 브라우저에서 간단히 확인합니다.',500,72,560);
}

// 21 C++ lesson map
{
  const s=p.slides.add();n++;base(s,'C++ Course',n);title(s,'C++ 강좌 단원별 핵심','표준 라이브러리와 객체지향을 함께 익혀 더 큰 프로그램의 구조를 이해합니다.');
  point(s,1,'iostream과 string','cout으로 출력하고 string으로 문자열을 관리합니다.',205,80,520);
  point(s,2,'vector와 참조','크기가 변하는 배열과 복사를 줄이는 참조를 사용합니다.',325,80,520);
  point(s,3,'클래스와 객체','데이터와 기능을 묶고 생성자로 초기 상태를 정합니다.',445,80,520);
  point(s,4,'상속과 다형성','공통 기능을 물려받고 override로 동작을 바꿉니다.',565,80,520);
  code(s,'class Student : public Person {\npublic:\n  void study() const {\n    std::cout << getName() << "이 공부합니다.\\n";\n  }\n};',690,220,480,340);
}

// 22 Close
{
  const s=p.slides.add();n++;base(s,'Summary',n);text(s,'하나의 사이트에서\n소개·기록·학습을 연결합니다',100,166,1080,130,54,C.white,true,'center');text(s,'포트폴리오는 정보를 보여주는 데서 끝나지 않고, 사용자가 직접 기록하고 학습하는 공간으로 확장되었습니다.',170,330,940,76,24,C.muted,false,'center');
  point(s,1,'현재 완성','반응형 포트폴리오, 스마트 링크, 아이디어 저장, 회원 기능과 세 개의 강좌',486,160,450);
  point(s,2,'다음 개선','서버 기반 계정, 기기 간 데이터 동기화, 실제 C/C++ 온라인 컴파일 기능',486,680,450);
  text(s,'END',560,640,160,30,14,C.light,true,'center');
}

await fs.mkdir(path.join(BUILD,'renders'),{recursive:true});
await fs.mkdir(OUT,{recursive:true});
for(const [i,s] of p.slides.items.entries()){
  const png=await p.export({slide:s,format:'png',scale:1});
  await fs.writeFile(path.join(BUILD,'renders',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await png.arrayBuffer()));
}
const montage=await p.export({format:'webp',montage:true});
await fs.writeFile(path.join(BUILD,'montage.webp'),new Uint8Array(await montage.arrayBuffer()));
const {finalizePresentation}=await import(pathToFileURL(path.join(SKILL,'container_tools/artifact_tool_utils.mjs')).href);
const candidate=path.join(BUILD,'candidate.pptx');
await (await PresentationFile.exportPptx(p)).save(candidate);
await finalizePresentation({
  workspaceDir:ROOT,candidatePath:candidate,finalPath:FINAL,pythonExecutable:PY,
  integrityValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_package_integrity.py'),
  layoutValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_layout_geometry.py'),
  layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-heading-fit'],
  explicitTotalSlideCount:22,requiredNativeTableOwnerSlides:[],requiredNativeChartOwnerSlides:[],
  fontPolicy:{basis:'design',families:[FONT]},verifyArtifactToolImport:true,
  receiptPath:path.join(BUILD,'portfolio_site_guide_all_v2.validation.json')
});
console.log(FINAL);
