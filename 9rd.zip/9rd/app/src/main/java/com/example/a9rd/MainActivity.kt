
package com.example.a9rd

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    // 버튼 클릭 시 실행
    fun onClickSum(v: View) {
        findViewById<TextView>(R.id.resultTextView).text = (200 + 300).toString()
    }
}
