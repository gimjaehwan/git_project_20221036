(() => {
  const script = document.createElement('script');
  script.src = '../js/auth.js';
  document.head.appendChild(script);
})();
