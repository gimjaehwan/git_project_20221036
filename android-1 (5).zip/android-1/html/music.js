(() => {
  const script = document.createElement('script');
  script.src = '../js/music.js';
  document.head.appendChild(script);
})();
