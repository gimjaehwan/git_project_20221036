package com.example.a2th

import android.util.Log
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLog


/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class ExampleUnitTest {
    @Before
    fun setUpLogOutput() {
        ShadowLog.stream = System.out
    }

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)

        val myName = "김재환"      // String형 추론
        val age: Int = 25          // 명시적 Int형 지정
        var numOne = 1;
        var numTwo = 3000000000
        var myByte: Byte = 1
        var myInt: Int = 20

        var myBoolean : Boolean = true

        var myChar1: Char = 'K'  // 변수 myChar1에 문자 값 'K'를 저장
        var myChar2: Char = 'o'  // 변수 myChar2에 문자 값 'o'를 저장
        var myChar3: Char = 't'  // 변수 myChar3에 문자 값 't'를 저장
        var myChar4: Char = 'l'  // 변수 myChar4에 문자 값 'l'을 저장
        var myChar5: Char = 'i'  // 변수 myChar5에 문자 값 'i'를 저장
        var myChar6: Char = 'n'  // 변수 myChar6에 문자 값 'n'을 저장

        var myLong = 25L  // 명시적 Long형 지정

        var myArray: IntArray = intArrayOf(1, 2, 3, 4, 5)

        var myString1: String = "Kotlin\n"  // 명시적 String형 지정
        var myString2: String = "Java"      // 명시적 String형 지정
        var myX: Int = 100
        var myY: Long = myX.toLong()

        var x: Int = 5
        var y: Int = 10

        var num: Int = 10
        var result : String

        var day: Int = 2

        var numbers = arrayOf(1, 2, 3, 4, 5)

        var score : Int = 95
        var attendanceRate : Int = 80



        Log.d("코틀린 : 문자열 자료형", "String : " + myString1)
        Log.d("코틀린 : 문자열 자료형", "String : " + myString2)

        Log.d(
            "코틀린 : 배열 자료형",
            "배열의 3번째 값 : " + myArray[2]
        )

        Log.d("코틀린 : 정수 자료형", "Int : " + numOne)
        Log.d("코틀린 : 정수 자료형", "Long : " + numTwo)
        Log.d("코틀린 : 정수 자료형", "Byte : " + myByte)
        Log.d("코틀린 : 정수 자료형", "Int : " + myInt)
        Log.d("코틀린 : 정수 자료형", "Long : " + myLong)


        Log.d("코틀린: 불변 변수 val", "나의 이름은 " + myName + " 나이는 " + age)

        Log.d("코틀린: 부울린 자료형 ", "Boolean : " + myBoolean)
        Log.d(
            "코틀린 : 문자 자료형",
            "Char : " + myChar1 + myChar2 + myChar3 + myChar4 + myChar5 + myChar6
        )
        Log.d("코틀린 : 자료형 반환","Int : " + myX)
        Log.d("코블린 : 자료형 변환", "Long : " + myY)

        Log.d("코틀린 : 산술 연산자 ", "x + y = " + (x + y))
        Log.d("코틀린 : 산술 연산자 ", "x - y = " + (x - y))
        Log.d("코틀린 : 산술 연산자 ", "x / y = " + (x / y))
        Log.d("코틀린 : 산술 연산자 ", "x * y = " + (x * y))
        Log.d("코틀린 : 산술 연산자 ", "x % y = " + (x % y))


        Log.d("코틀린 : 비교 연산자", "x > y = " + (x > y))
        Log.d("코틀린 : 비교 연산자", "x < y = " + (x < y))
        Log.d("코틀린 : 비교 연산자", "x >= y = " + (x >= y))
        Log.d("코틀린 : 비교 연산자", "x <= y = " + (x <= y))
        Log.d("코틀린 : 비교 연산자", "x == y = " + (x == y))
        Log.d("코틀린 : 비교 연산자", "x != y = " + (x != y))

        y += x
        Log.d("코틀린 : 할당 연산자" , "y += x => y = " + y)

        y -= x
        Log.d("코틀린 : 할당 연산자" , "y -= x => y = " + y)

        y *= x
        Log.d("코틀린 : 할당 연산자" , "y *= x => y = " + y)

        y /= x
        Log.d("코틀린 : 할당 연산자" , "y /= x => y = " + y)

        y %= x
        Log.d("코틀린 : 할당 연산자" , "y %= x => y = " + y)

        Log.d("코틀린 : 증감 연산자 ", "++x = " + (++x))
        Log.d("코틀린 : 증감 연산자 ", "--x = " + (--x))
        Log.d("코틀린 : 증감 연산자 ", "--x = " + (--x))
        Log.d("코틀린 : 증감 연산자 ", "--x = " + (--x))
        Log.d("코틀린 : 증감 연산자 ", "--x = " + (--x))

        if (num % 2 == 0)
        {
            Log.d("코틀린 : if -else 조건문 ", "숫자 " + num + "은 짝수")
        }
        else
        {
            Log.d("코틀린 : if-else 조건문 ", "숫자 " + num + "은 홀수")
        }

        if (num > 0)
        {
            result = "숫자 " + num + "은 양수"
        }
        else if (num == 0)
        {
            result = "숫자 " + num + "은 0"
        }
        else
        {
            result = "숫자 " + num + "은 음수"
        }
        Log.d("코틀린 : if-else if 조건문 " , result)

        if(num > 0)
        {
            if (num % 2 ==0)
            {
                result = "숫자 " + num + "은 양수이고 짝수"
            }
            else
            {
                result = "숫자 " + num + "은 양수이고 홀수"
            }
        }
        else
        {
            if (num % 2 == 0)
            {
                result = "숫자 " + num + "은 양수이고 짝수"
            }
            else
            {
                result = "숫자 " + num + "은 음수이고 홀수"
            }

        }

        Log.d("코틀린 : 중첩 if 조건문", result)

        when (day)
        {
            1 -> result = "Monday"
            2 -> result = "Tuesday"
            3 -> result = "Wednesday"
            4 -> result = "Thursday"
            5 -> result = "Friday"
            6 -> result = "Saturday"
            7 -> result = "Sunday"
            else -> result = "Invalid day"
        }

        Log.d("코틀린 : when", result)

        for (i in 5 downTo 1 step 2)
        {
            Log.d("코틀린 : for 반복문 ", "반복 변수 : " + i)
        }

        for (i in numbers)
        {
            if (i in numbers)
            {
                if (i % 2 == 1)
                {
                    Log.d("코틀린 : for 반복문 ", "반복 변수 : " + i)
                }
            }
        }

        if (70 < attendanceRate && attendanceRate < 80)
        {
            Log.d("학점 판별 : ", "D")
        }
        else
        {
            if (attendanceRate == 90)
            {
                // A 학점
                Log.d("학점 판별 : ", "A")
            }

            else if (attendanceRate == 85)
            {
                Log.d("학점 판별 : ", "B")
            }

            else if (attendanceRate == 80)
            {
                // C 학점
                Log.d("학점 판별 : ", "C")
            }

            else
            {
                // F 학점
                Log.d("학점 판별 : ", "F")
            }
        }

       for (i in 10..13)
       {
          for (j in 5..10)
          {
              print("$i x $j = ${i * j}\t")

          }
           println()

       }


    }

}
